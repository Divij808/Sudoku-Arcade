import asyncio
import pygame

pygame.font.init()

# Use your exact board
board = [
    [0, 0, 3, 0, 0, 0, 6, 8, 0],
    [6, 0, 0, 0, 0, 8, 0, 0, 0],
    [0, 7, 0, 0, 3, 0, 5, 0, 2],
    [0, 0, 0, 5, 0, 6, 3, 0, 0],
    [0, 0, 0, 7, 0, 0, 0, 0, 0],
    [4, 0, 0, 1, 8, 0, 0, 9, 0],
    [0, 0, 1, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 4, 0, 8, 0, 0],
    [0, 5, 2, 0, 0, 0, 0, 0, 0],
]
original_board = [[cell != 0 for cell in row] for row in board]

available_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
when = 0

# Global tracking stacks for your backtracking logic
previous_empty = []
previous_available_numbers = []


# --- Find Empty ---
def find_empty(bo=board):
    for i in range(len(bo)):
        for j in range(len(bo[0])):
            if bo[i][j] == 0:
                return i, j  # row, col
    return None


def valid(bo, num, pos):
    for i in range(len(bo[0])):
        if bo[pos[0]][i] == num and pos[1] != i:
            return False
    for i in range(len(bo)):
        if bo[i][pos[1]] == num and pos[0] != i:
            return False
    box_x, box_y = pos[1] // 3, pos[0] // 3
    for i in range(box_y * 3, box_y * 3 + 3):
        for j in range(box_x * 3, box_x * 3 + 3):
            if bo[i][j] == num and (i, j) != pos:
                return False
    return True


def solving_bot(board):
    global previous_empty, previous_available_numbers

    empty = find_empty()
    if not empty:
        return
    empty_space_y, empty_space_x = empty

    available_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    run = True
    while run:
        # Checking the row
        for i in range(len(board[empty_space_y])):
            if board[empty_space_y][i] in available_numbers:
                available_numbers.remove(board[empty_space_y][i])

        # Checking the column
        for j in range(len(board)):
            if board[j][empty_space_x] in available_numbers:
                available_numbers.remove(board[j][empty_space_x])

        # Ensure 3x3 box rules are also checked using your valid function
        available_numbers = [
            n for n in available_numbers if valid(board, n, (empty_space_y, empty_space_x))
        ]

        # Only assign if there's a valid number left to avoid IndexError
        if available_numbers:
            board[empty_space_y][empty_space_x] = available_numbers[0]

            # Push current cell and remaining choices (minus the one we just used) to stacks
            previous_empty.append((empty_space_y, empty_space_x))
            next_choices = list(available_numbers)
            next_choices.remove(next_choices[0])
            previous_available_numbers.append(next_choices)

            run = False
        else:
            # DEAD END: Backtrack using the stack
            board[empty_space_y][empty_space_x] = 0

            if previous_empty:
                p_y, p_x = previous_empty.pop()
                p_av = previous_available_numbers.pop()

                # Keep popping backward if previous cells have no choices left
                while not p_av and previous_empty:
                    board[p_y][p_x] = 0
                    p_y, p_x = previous_empty.pop()
                    p_av = previous_available_numbers.pop()

                if p_av:
                    board[p_y][p_x] = p_av[0]
                    previous_empty.append((p_y, p_x))
                    new_av = list(p_av)
                    new_av.pop(0)
                    previous_available_numbers.append(new_av)
                    run = False
                else:
                    board[p_y][p_x] = 0
                    run = False
            else:
                run = False


# Initialize Window
WIDTH, HEIGHT = 540, 600
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sudoku Visualizer")
font = pygame.font.SysFont("comicsans", 40)
win_font = pygame.font.SysFont("comicsans", 50)


def draw_grid():
    win.fill((255, 255, 255))
    for i in range(10):
        thick = 4 if i % 3 == 0 else 1
        pygame.draw.line(win, (0, 0, 0), (0, i * 60), (540, i * 60), thick)
        pygame.draw.line(win, (0, 0, 0), (i * 60, 0), (i * 60, 540), thick)


def draw_numbers():
    for i in range(9):
        for j in range(9):
            if board[i][j] != 0:
                color = (0, 0, 255) if original_board[i][j] else (0, 0, 0)
                text = font.render(str(board[i][j]), 1, color)
                win.blit(text, (j * 60 + 20, i * 60 + 10))


async def main():
    run = True
    started = False
    won = False

    while run:
        draw_grid()
        draw_numbers()

        # Check if the board is completed using find_empty
        if find_empty(board) is None and not won:
            won = True

        # If won, display a success banner at the bottom
        if won:
            victory_text = win_font.render("SOLVED!", 1, (0, 200, 0))
            win.blit(victory_text, (180, 550))
        elif not started:
            start_text = win_font.render("Press SPACE to Solve", 1, (150, 150, 150))
            win.blit(start_text, (50, 550))

        pygame.display.update()

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not started:
                    started = True

        # If solver is started, execute your solving loop step-by-step
        if started and not won:
            if find_empty(board) is not None:
                solving_bot(board)
                # Replaced pygame.time.delay(20) with async sleep for web compatibility
                await asyncio.sleep(0.02)
        else:
            await asyncio.sleep(0.01)

        # Yield control back to the browser browser event loop
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
