import asyncio
import copy
import random

import pygame

pygame.init()
pygame.font.init()

WIDTH, HEIGHT = 670, 650
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ultimate Sudoku Suite")

font = pygame.font.SysFont("comicsans", 35)
title_font = pygame.font.SysFont("comicsans", 45)
small_font = pygame.font.SysFont("comicsans", 25)

DEFAULT_BOARD = [[0] * 9 for _ in range(9)]
custom_board = copy.deepcopy(DEFAULT_BOARD)
active_board = copy.deepcopy(DEFAULT_BOARD)


def find_empty(b):
    for r in range(9):
        for c in range(9):
            if b[r][c] == 0:
                return r, c
    return None


def valid(b, num, pos):
    r, c = pos
    if any(b[r][col] == num for col in range(9) if col != c):
        return False
    if any(b[row][c] == num for row in range(9) if row != r):
        return False
    br, bc = r // 3, c // 3
    for row in range(br * 3, br * 3 + 3):
        for col in range(bc * 3, bc * 3 + 3):
            if (row, col) != pos and b[row][col] == num:
                return False
    return True


def fill_board(b):
    empty = find_empty(b)
    if not empty:
        return True
    r, c = empty
    nums = list(range(1, 10))
    random.shuffle(nums)
    for num in nums:
        if valid(b, num, (r, c)):
            b[r][c] = num
            if fill_board(b):
                return True
            b[r][c] = 0
    return False


def count_solutions(b, limit=2):
    solutions = 0

    def solve():
        nonlocal solutions
        if solutions >= limit:
            return
        best_cell, best_cand = None, None
        for r in range(9):
            for c in range(9):
                if b[r][c] != 0:
                    continue
                cand = [n for n in range(1, 10) if valid(b, n, (r, c))]
                if not cand:
                    return
                if best_cand is None or len(cand) < len(best_cand):
                    best_cell, best_cand = (r, c), cand
                    if len(cand) == 1:
                        break
            if best_cand and len(best_cand) == 1:
                break
        if not best_cell:
            solutions += 1
            return
        r, c = best_cell
        for num in best_cand:
            b[r][c] = num
            solve()
            b[r][c] = 0
            if solutions >= limit:
                return

    solve()
    return solutions


def has_unique_solution(b):
    return count_solutions(copy.deepcopy(b), 2) == 1


def generate_random_sudoku():
    b = [[0] * 9 for _ in range(9)]
    fill_board(b)
    cells = [(r, c) for r in range(9) for c in range(9)]
    random.shuffle(cells)
    removed = 0
    for r, c in cells:
        if removed >= 45:
            break
        orig = b[r][c]
        b[r][c] = 0
        if has_unique_solution(b):
            removed += 1
        else:
            b[r][c] = orig
    return b


def get_bot_generator(board_ref):
    stack_empty, stack_avail = [], []

    def generator_step():
        empty = find_empty(board_ref)
        if not empty:
            return True
        r, c = empty
        avail = [n for n in range(1, 10) if valid(board_ref, n, (r, c))]
        if avail:
            board_ref[r][c] = avail[0]
            stack_empty.append((r, c))
            rem = list(avail)
            rem.pop(0)
            stack_avail.append(rem)
        else:
            board_ref[r][c] = 0
            if stack_empty:
                pr, pc = stack_empty.pop()
                pavail = stack_avail.pop()
                while not pavail and stack_empty:
                    board_ref[pr][pc] = 0
                    pr, pc = stack_empty.pop()
                    pavail = stack_avail.pop()
                if pavail:
                    board_ref[pr][pc] = pavail[0]
                    stack_empty.append((pr, pc))
                    n_avail = list(pavail)
                    n_avail.pop(0)
                    stack_avail.append(n_avail)
                else:
                    board_ref[pr][pc] = 0
            else:
                return False
        return False

    return generator_step


async def main_menu():
    global active_board, custom_board
    while True:
        win.fill((240, 248, 255))
        title = title_font.render("SUDOKU ARCADE", True, (20, 40, 80))
        win.blit(title, (WIDTH // 2 - title.get_width() // 2, 60))
        buttons = [
            ("1. Play Yourself (New Random Board)", 150),
            ("2. Watch Bot Solver (New Random Board)", 230),
            ("3. Race Against Bot (New Random Board)", 310),
            ("4. Custom Board Editor", 390),
            ("Quit", 470),
        ]
        mouse_pos = pygame.mouse.get_pos()
        rects = []
        for text, y in buttons:
            rect = pygame.Rect(WIDTH // 2 - 200, y, 400, 50)
            rects.append((rect, text))
            pygame.draw.rect(win, (70, 130, 180), rect, border_radius=8)
            label = small_font.render(text, True, (255, 255, 255))
            win.blit(
                label,
                (
                    rect.x + (rect.width - label.get_width()) // 2,
                    rect.y + (rect.height - label.get_height()) // 2,
                ),
            )
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "QUIT"
            if event.type == pygame.MOUSEBUTTONDOWN:
                for rect, text in rects:
                    if rect.collidepoint(mouse_pos):
                        if text.startswith("1."):
                            active_board = generate_random_sudoku()
                            await play_manual_mode()
                        elif text.startswith("2."):
                            active_board = generate_random_sudoku()
                            await watch_bot_mode()
                        elif text.startswith("3."):
                            await race_mode()
                        elif text.startswith("4."):
                            await custom_editor_mode()
                        elif text == "Quit":
                            return "QUIT"
        await asyncio.sleep(0.01)


async def play_manual_mode():
    selected = None
    orig_cells = [[cell != 0 for cell in row] for row in active_board]
    while True:
        win.fill((255, 255, 255))
        for i in range(10):
            thick = 4 if i % 3 == 0 else 1
            pygame.draw.line(win, (0, 0, 0), (0, i * 60), (540, i * 60), thick)
            pygame.draw.line(win, (0, 0, 0), (i * 60, 0), (i * 60, 540), thick)
        if selected:
            r, c = selected
            pygame.draw.rect(win, (173, 216, 230), (c * 60 + 1, r * 60 + 1, 58, 58))
        for r in range(9):
            for c in range(9):
                val = active_board[r][c]
                if val != 0:
                    color = (0, 0, 255) if orig_cells[r][c] else (0, 0, 0)
                    win.blit(
                        font.render(str(val), True, color),
                        (c * 60 + 20, r * 60 + 10),
                    )
        back_rect = pygame.Rect(20, 570, 120, 40)
        pygame.draw.rect(win, (200, 50, 50), back_rect, border_radius=5)
        win.blit(
            small_font.render("<- Menu", True, (255, 255, 255)),
            (back_rect.x + 20, back_rect.y + 8),
        )
        if find_empty(active_board) is None:
            win.blit(
                font.render("PUZZLE SOLVED!", True, (0, 150, 0)), (180, 575)
            )
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if back_rect.collidepoint(pos):
                    return
                if pos[1] < 540:
                    selected = (pos[1] // 60, pos[0] // 60)
            if event.type == pygame.KEYDOWN and selected:
                r, c = selected
                if not orig_cells[r][c]:
                    if event.key in range(pygame.K_1, pygame.K_10):
                        val = int(event.unicode)
                        if valid(active_board, val, selected):
                            active_board[r][c] = val
                    elif event.key in [
                        pygame.K_BACKSPACE,
                        pygame.K_DELETE,
                        pygame.K_0, ]:
                        active_board[r][c] = 0
        await asyncio.sleep(0.01)


async def watch_bot_mode():
    started = False
    step_func = get_bot_generator(active_board)
    orig_cells = [[cell != 0 for cell in row] for row in active_board]
    while True:
        win.fill((255, 255, 255))
        for i in range(10):
            thick = 4 if i % 3 == 0 else 1
            pygame.draw.line(win, (0, 0, 0), (0, i * 60), (540, i * 60), thick)
            pygame.draw.line(win, (0, 0, 0), (i * 60, 0), (i * 60, 540), thick)
        for r in range(9):
            for c in range(9):
                val = active_board[r][c]
                if val != 0:
                    color = (0, 0, 255) if orig_cells[r][c] else (0, 120, 0)
                    win.blit(
                        font.render(str(val), True, color),
                        (c * 60 + 20, r * 60 + 10),
                    )
        back_rect = pygame.Rect(20, 570, 120, 40)
        pygame.draw.rect(win, (200, 50, 50), back_rect, border_radius=5)
        win.blit(
            small_font.render("<- Menu", True, (255, 255, 255)),
            (back_rect.x + 20, back_rect.y + 8),
        )
        if not started:
            win.blit(
                small_font.render(
                    "Press SPACE to Start Bot", True, (100, 100, 100)
                ),
                (160, 580),
            )
        elif find_empty(active_board) is None:
            win.blit(font.render("SOLVED!", True, (0, 200, 0)), (180, 575))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if (
                    event.type == pygame.MOUSEBUTTONDOWN
                    and back_rect.collidepoint(pygame.mouse.get_pos())
            ):
                return
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                started = True
        if started and find_empty(active_board) is not None:
            step_func()
            await asyncio.sleep(0.02)
        else:
            await asyncio.sleep(0.01)


async def race_mode():
    shared_base = generate_random_sudoku()
    player_board = copy.deepcopy(shared_base)
    bot_board = copy.deepcopy(shared_base)
    bot_step = get_bot_generator(bot_board)
    selected, started, winner = None, False, None
    orig_cells = [[cell != 0 for cell in row] for row in shared_base]
    while True:
        win.fill((250, 250, 250))
        win.blit(
            small_font.render(
                "RACE! Fill your board before the Bot finishes!", True, (0, 0, 0)
            ),
            (20, 10),
        )
        for i in range(10):
            thick = 3 if i % 3 == 0 else 1
            pygame.draw.line(
                win, (0, 0, 0), (0, i * 45 + 40), (405, i * 45 + 40), thick
            )
            pygame.draw.line(win, (0, 0, 0), (i * 45, 40), (i * 45, 445), thick)
        if selected:
            r, c = selected
            pygame.draw.rect(
                win, (173, 216, 230), (c * 45 + 1, r * 45 + 41, 43, 43)
            )
        for r in range(9):
            for c in range(9):
                val = player_board[r][c]
                if val != 0:
                    color = (0, 0, 255) if orig_cells[r][c] else (0, 0, 0)
                    win.blit(
                        small_font.render(str(val), True, color),
                        (c * 45 + 15, r * 45 + 50),
                    )
        win.blit(
            small_font.render("Bot Progress:", True, (100, 100, 100)), (430, 40)
        )
        for i in range(10):
            thick = 2 if i % 3 == 0 else 1
            pygame.draw.line(
                win,
                (100, 100, 100),
                (430, i * 25 + 70),
                (655, i * 25 + 70),
                thick,
            )
            pygame.draw.line(
                win,
                (100, 100, 100),
                (i * 25 + 430, 70),
                (i * 25 + 430, 295),
                thick,
            )
        for r in range(9):
            for c in range(9):
                val = bot_board[r][c]
                if val != 0:
                    win.blit(
                        pygame.font.SysFont("comicsans", 18).render(
                            str(val), True, (0, 120, 0)
                        ),
                        (c * 25 + 436, r * 25 + 73),
                    )
        back_rect = pygame.Rect(20, 600, 100, 35)
        pygame.draw.rect(win, (200, 50, 50), back_rect, border_radius=5)
        win.blit(
            small_font.render("<- Menu", True, (255, 255, 255)), (28, 606)
        )
        if not started:
            win.blit(
                small_font.render(
                    "Press SPACE to Begin Race!", True, (200, 0, 0)
                ),
                (140, 606),
            )
        elif winner:
            win.blit(font.render(winner, True, (200, 0, 0)), (430, 320))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if back_rect.collidepoint(pos):
                    return
                if 40 <= pos[1] <= 445 and 0 <= pos[0] <= 405:
                    selected = ((pos[1] - 40) // 45, pos[0] // 45)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not started:
                    started = True
                elif selected and started and not winner:
                    r, c = selected
                    if not orig_cells[r][c]:
                        if event.key in range(pygame.K_1, pygame.K_10):
                            val = int(event.unicode)
                            if valid(player_board, val, selected):
                                player_board[r][c] = val
                        elif event.key in [
                            pygame.K_BACKSPACE,
                            pygame.K_DELETE,
                            pygame.K_0,
                        ]:
                            player_board[r][c] = 0
        if started and not winner:
            if find_empty(player_board) is None:
                winner = "YOU WIN!"
            elif find_empty(bot_board) is None:
                winner = "BOT WINS!"
        if started and not winner:
            for _ in range(3):
                if find_empty(bot_board) is not None:
                    bot_step()
            await asyncio.sleep(0.02)
        else:
            await asyncio.sleep(0.01)


async def custom_editor_mode():
    global custom_board
    selected = None
    while True:
        win.fill((255, 255, 255))
        for i in range(10):
            thick = 4 if i % 3 == 0 else 1
            pygame.draw.line(win, (0, 0, 0), (0, i * 60), (540, i * 60), thick)
            pygame.draw.line(win, (0, 0, 0), (i * 60, 0), (i * 60, 540), thick)
        if selected:
            r, c = selected
            pygame.draw.rect(
                win, (173, 216, 230), (c * 60 + 1, r * 60 + 1, 58, 58)
            )
        for r in range(9):
            for c in range(9):
                val = custom_board[r][c]
                if val != 0:
                    win.blit(
                        font.render(str(val), True, (0, 0, 0)),
                        (c * 60 + 20, r * 60 + 10),
                    )
        back_rect = pygame.Rect(20, 570, 100, 40)
        pygame.draw.rect(win, (200, 50, 50), back_rect, border_radius=5)
        win.blit(
            small_font.render("<- Menu", True, (255, 255, 255)), (28, 578)
        )
        win.blit(
            small_font.render(
                "Build a custom board for testing", True, (100, 100, 100)
            ),
            (135, 580), )
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if back_rect.collidepoint(pos):
                    return
                if pos[1] < 540:
                    selected = (pos[1] // 60, pos[0] // 60)
            if event.type == pygame.KEYDOWN and selected:
                r, c = selected
                if event.key in range(pygame.K_1, pygame.K_10):
                    val = int(event.unicode)
                    if valid(custom_board, val, selected):
                        custom_board[r][c] = val
                elif event.key in [
                    pygame.K_BACKSPACE,
                    pygame.K_DELETE,
                    pygame.K_0, ]:
                    custom_board[r][c] = 0
        await asyncio.sleep(0.01)


async def main():
    while True:
        if await main_menu() == "QUIT":
            break
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
